<template>
    <div id="app">
        <router-view />
    </div>
</template>

<style lang="stylus">
body {
    margin: 0;
    color: white;
    line-height: 1;
    font-family: Helvetica, Tahoma, Arial, 'PingFang SC', 'Hiragino Sans GB', 'Heiti SC', 'Microsoft YaHei', 'WenQuanYi Micro Hei';
}
* {
    margin: 0;
    padding: 0;
}
ul, li {
    list-style: none;
}
</style>
