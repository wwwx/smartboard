<template>
    <div class="about">
        
    </div>
</template>

<script lang="ts">
import { Component, Prop, Vue } from "vue-property-decorator";

@Component
export default class MonitorItem extends Vue {
    
}
</script>

<style lang="stylus" scoped>


</style>